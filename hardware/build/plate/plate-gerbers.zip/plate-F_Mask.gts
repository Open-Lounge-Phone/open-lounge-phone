%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.ProjectId,plate,706c6174-652e-46b6-9963-61645f706362,r0.1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
